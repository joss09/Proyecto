var ellipseRadius = 100;
function setup() {
    createCanvas(800, 600);
    colorMode(RGB, 255);
    background(0);
    smooth();
    frameRate(60);
}
function draw() {
    noStroke();
    fill( (mouseX/width)*255, (mouseY/height)*255, 0, 25); // ( R, G, B, A )
    ellipse(mouseX, mouseY, ellipseRadius, ellipseRadius);
    textSize(30);
    stroke("gold");
    fill("gold");
    text("La programación creativa es:",50,100);
    textSize(50);
    fill(random(255),random(255),random(255))
    stroke(random(255),random(255),random(255));
    text("GENERATIVA",100,200);
     textSize(25);
    stroke("pink");
    fill("pink");
    text("Una creación geométrica del diseño en base a una idea o concepto,",0,400);
    text("gama de colores y formas",0,430);
}