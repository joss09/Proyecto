var latido;
var a;
var nivel;

function preload(){
  latido=loadSound("latidos.mp3");
}

function setup() {
  createCanvas(800,800);
  latido.play();
  a = new p5.Amplitude();
}

function draw() {
  background("black");
  nivel=a.getLevel();
  nivel=map(nivel,0,5,50,400);
  fill("red");
  bezier(nivel+100,nivel+100,nivel+60,nivel+30,nivel+10,nivel+100,nivel+100,nivel+200);
  bezier(nivel+99,nivel+99,nivel+130,nivel+30,nivel+200,nivel+90,nivel+99,nivel+200);
  stroke(5);
  fill(random(255),0,random(255));
  textSize(40);
  text("PROGRAMACIÓN CREATIVA",120,50);
  text("¿Qué es?",400,200);
  fill("pink");
  textSize(17);
  text("Es un  enfoque  didáctico  incluyente,  dinámico, flexible e interesante que promueve el uso del software",10,400);
  text("como un medio para representar expresiones originales y creativas combinando un enfoque algoritmico",10,420);
  text("de análisis, diseño y resolución  de  problemas,  que  termine por  generar una solución creativa",10,440);
  text("y factible de ser implementada en software",10,460)
}